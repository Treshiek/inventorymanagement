namespace inventory
{
    partial class DashboardForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.pnlHeader = new System.Windows.Forms.Panel();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.lblRole = new System.Windows.Forms.Label();
            this.btnLogout = new System.Windows.Forms.Button();
            this.pnlTotal = new System.Windows.Forms.Panel();
            this.stripTotal = new System.Windows.Forms.Panel();
            this.lblTitleTotal = new System.Windows.Forms.Label();
            this.lblCountTotal = new System.Windows.Forms.Label();
            this.pnlInStock = new System.Windows.Forms.Panel();
            this.stripInStock = new System.Windows.Forms.Panel();
            this.lblTitleInStock = new System.Windows.Forms.Label();
            this.lblCountInStock = new System.Windows.Forms.Label();
            this.pnlLow = new System.Windows.Forms.Panel();
            this.stripLow = new System.Windows.Forms.Panel();
            this.lblTitleLow = new System.Windows.Forms.Label();
            this.lblCountLow = new System.Windows.Forms.Label();
            this.pnlOut = new System.Windows.Forms.Panel();
            this.stripOut = new System.Windows.Forms.Panel();
            this.lblTitleOut = new System.Windows.Forms.Label();
            this.lblCountOut = new System.Windows.Forms.Label();
            this.pnlForm = new System.Windows.Forms.Panel();
            this.lblProductName = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblCategory = new System.Windows.Forms.Label();
            this.cmbCategory = new System.Windows.Forms.ComboBox();
            this.lblUnitPrice = new System.Windows.Forms.Label();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.lblDescription = new System.Windows.Forms.Label();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.lblQuantity = new System.Windows.Forms.Label();
            this.txtQuantity = new System.Windows.Forms.TextBox();
            this.lblReorderLevel = new System.Windows.Forms.Label();
            this.txtReorder = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.lblList = new System.Windows.Forms.Label();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.lblSearch = new System.Windows.Forms.Label();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.grid = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.grid)).BeginInit();
            this.SuspendLayout();
            //
            // pnlHeader
            //
            this.pnlHeader.BackColor = System.Drawing.Color.White;
            this.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlHeader.Size = new System.Drawing.Size(1100, 70);
            this.pnlHeader.Name = "pnlHeader";
            //
            // lblWelcome
            //
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblWelcome.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblWelcome.Location = new System.Drawing.Point(24, 6);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Text = "Welcome!";
            //
            // lblRole
            //
            this.lblRole.AutoSize = true;
            this.lblRole.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblRole.ForeColor = System.Drawing.Color.DimGray;
            this.lblRole.Location = new System.Drawing.Point(27, 42);
            this.lblRole.Name = "lblRole";
            //
            // btnLogout
            //
            this.btnLogout.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
            this.btnLogout.BackColor = System.Drawing.Color.MidnightBlue;
            this.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogout.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnLogout.ForeColor = System.Drawing.Color.White;
            this.btnLogout.Location = new System.Drawing.Point(955, 15);
            this.btnLogout.Size = new System.Drawing.Size(125, 40);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.TabIndex = 20;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            //
            // pnlTotal
            //
            this.pnlTotal.BackColor = System.Drawing.Color.White;
            this.pnlTotal.Location = new System.Drawing.Point(25, 85);
            this.pnlTotal.Size = new System.Drawing.Size(245, 90);
            this.pnlTotal.Name = "pnlTotal";
            //
            // stripTotal
            //
            this.stripTotal.BackColor = System.Drawing.Color.FromArgb(70, 130, 180);
            this.stripTotal.Dock = System.Windows.Forms.DockStyle.Top;
            this.stripTotal.Size = new System.Drawing.Size(245, 6);
            this.stripTotal.Name = "stripTotal";
            //
            // lblTitleTotal
            //
            this.lblTitleTotal.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblTitleTotal.ForeColor = System.Drawing.Color.FromArgb(70, 130, 180);
            this.lblTitleTotal.Location = new System.Drawing.Point(0, 14);
            this.lblTitleTotal.Size = new System.Drawing.Size(245, 24);
            this.lblTitleTotal.Name = "lblTitleTotal";
            this.lblTitleTotal.Text = "Total Products";
            this.lblTitleTotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // lblCountTotal
            //
            this.lblCountTotal.Font = new System.Drawing.Font("Segoe UI", 26F, System.Drawing.FontStyle.Bold);
            this.lblCountTotal.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblCountTotal.Location = new System.Drawing.Point(0, 40);
            this.lblCountTotal.Size = new System.Drawing.Size(245, 44);
            this.lblCountTotal.Name = "lblCountTotal";
            this.lblCountTotal.Text = "0";
            this.lblCountTotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // pnlInStock
            //
            this.pnlInStock.BackColor = System.Drawing.Color.White;
            this.pnlInStock.Location = new System.Drawing.Point(295, 85);
            this.pnlInStock.Size = new System.Drawing.Size(245, 90);
            this.pnlInStock.Name = "pnlInStock";
            //
            // stripInStock
            //
            this.stripInStock.BackColor = System.Drawing.Color.FromArgb(46, 160, 90);
            this.stripInStock.Dock = System.Windows.Forms.DockStyle.Top;
            this.stripInStock.Size = new System.Drawing.Size(245, 6);
            this.stripInStock.Name = "stripInStock";
            //
            // lblTitleInStock
            //
            this.lblTitleInStock.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblTitleInStock.ForeColor = System.Drawing.Color.FromArgb(46, 160, 90);
            this.lblTitleInStock.Location = new System.Drawing.Point(0, 14);
            this.lblTitleInStock.Size = new System.Drawing.Size(245, 24);
            this.lblTitleInStock.Name = "lblTitleInStock";
            this.lblTitleInStock.Text = "In Stock";
            this.lblTitleInStock.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // lblCountInStock
            //
            this.lblCountInStock.Font = new System.Drawing.Font("Segoe UI", 26F, System.Drawing.FontStyle.Bold);
            this.lblCountInStock.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblCountInStock.Location = new System.Drawing.Point(0, 40);
            this.lblCountInStock.Size = new System.Drawing.Size(245, 44);
            this.lblCountInStock.Name = "lblCountInStock";
            this.lblCountInStock.Text = "0";
            this.lblCountInStock.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // pnlLow
            //
            this.pnlLow.BackColor = System.Drawing.Color.White;
            this.pnlLow.Location = new System.Drawing.Point(565, 85);
            this.pnlLow.Size = new System.Drawing.Size(245, 90);
            this.pnlLow.Name = "pnlLow";
            //
            // stripLow
            //
            this.stripLow.BackColor = System.Drawing.Color.FromArgb(240, 150, 40);
            this.stripLow.Dock = System.Windows.Forms.DockStyle.Top;
            this.stripLow.Size = new System.Drawing.Size(245, 6);
            this.stripLow.Name = "stripLow";
            //
            // lblTitleLow
            //
            this.lblTitleLow.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblTitleLow.ForeColor = System.Drawing.Color.FromArgb(240, 150, 40);
            this.lblTitleLow.Location = new System.Drawing.Point(0, 14);
            this.lblTitleLow.Size = new System.Drawing.Size(245, 24);
            this.lblTitleLow.Name = "lblTitleLow";
            this.lblTitleLow.Text = "Low Stock";
            this.lblTitleLow.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // lblCountLow
            //
            this.lblCountLow.Font = new System.Drawing.Font("Segoe UI", 26F, System.Drawing.FontStyle.Bold);
            this.lblCountLow.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblCountLow.Location = new System.Drawing.Point(0, 40);
            this.lblCountLow.Size = new System.Drawing.Size(245, 44);
            this.lblCountLow.Name = "lblCountLow";
            this.lblCountLow.Text = "0";
            this.lblCountLow.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // pnlOut
            //
            this.pnlOut.BackColor = System.Drawing.Color.White;
            this.pnlOut.Location = new System.Drawing.Point(835, 85);
            this.pnlOut.Size = new System.Drawing.Size(245, 90);
            this.pnlOut.Name = "pnlOut";
            //
            // stripOut
            //
            this.stripOut.BackColor = System.Drawing.Color.FromArgb(220, 60, 60);
            this.stripOut.Dock = System.Windows.Forms.DockStyle.Top;
            this.stripOut.Size = new System.Drawing.Size(245, 6);
            this.stripOut.Name = "stripOut";
            //
            // lblTitleOut
            //
            this.lblTitleOut.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblTitleOut.ForeColor = System.Drawing.Color.FromArgb(220, 60, 60);
            this.lblTitleOut.Location = new System.Drawing.Point(0, 14);
            this.lblTitleOut.Size = new System.Drawing.Size(245, 24);
            this.lblTitleOut.Name = "lblTitleOut";
            this.lblTitleOut.Text = "Out of Stock";
            this.lblTitleOut.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // lblCountOut
            //
            this.lblCountOut.Font = new System.Drawing.Font("Segoe UI", 26F, System.Drawing.FontStyle.Bold);
            this.lblCountOut.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblCountOut.Location = new System.Drawing.Point(0, 40);
            this.lblCountOut.Size = new System.Drawing.Size(245, 44);
            this.lblCountOut.Name = "lblCountOut";
            this.lblCountOut.Text = "0";
            this.lblCountOut.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // pnlForm
            //
            this.pnlForm.BackColor = System.Drawing.Color.White;
            this.pnlForm.Location = new System.Drawing.Point(25, 190);
            this.pnlForm.Size = new System.Drawing.Size(1055, 235);
            this.pnlForm.Name = "pnlForm";
            //
            // lblProductName
            //
            this.lblProductName.AutoSize = true;
            this.lblProductName.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblProductName.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblProductName.Location = new System.Drawing.Point(20, 15);
            this.lblProductName.Name = "lblProductName";
            this.lblProductName.Text = "Product Name";
            //
            // txtName
            //
            this.txtName.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtName.Location = new System.Drawing.Point(20, 40);
            this.txtName.Size = new System.Drawing.Size(300, 29);
            this.txtName.Name = "txtName";
            //
            // lblCategory
            //
            this.lblCategory.AutoSize = true;
            this.lblCategory.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblCategory.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblCategory.Location = new System.Drawing.Point(340, 15);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Text = "Category";
            //
            // cmbCategory
            //
            this.cmbCategory.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cmbCategory.Location = new System.Drawing.Point(340, 40);
            this.cmbCategory.Size = new System.Drawing.Size(200, 29);
            this.cmbCategory.Name = "cmbCategory";
            //
            // lblUnitPrice
            //
            this.lblUnitPrice.AutoSize = true;
            this.lblUnitPrice.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblUnitPrice.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblUnitPrice.Location = new System.Drawing.Point(560, 15);
            this.lblUnitPrice.Name = "lblUnitPrice";
            this.lblUnitPrice.Text = "Unit Price";
            //
            // txtPrice
            //
            this.txtPrice.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtPrice.Location = new System.Drawing.Point(560, 40);
            this.txtPrice.Size = new System.Drawing.Size(160, 29);
            this.txtPrice.Name = "txtPrice";
            //
            // lblDescription
            //
            this.lblDescription.AutoSize = true;
            this.lblDescription.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblDescription.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblDescription.Location = new System.Drawing.Point(20, 85);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Text = "Description";
            //
            // txtDescription
            //
            this.txtDescription.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtDescription.Location = new System.Drawing.Point(20, 110);
            this.txtDescription.Size = new System.Drawing.Size(300, 110);
            this.txtDescription.Name = "txtDescription";
            //
            // lblQuantity
            //
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblQuantity.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblQuantity.Location = new System.Drawing.Point(340, 85);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Text = "Quantity";
            //
            // txtQuantity
            //
            this.txtQuantity.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtQuantity.Location = new System.Drawing.Point(340, 110);
            this.txtQuantity.Size = new System.Drawing.Size(200, 29);
            this.txtQuantity.Name = "txtQuantity";
            //
            // lblReorderLevel
            //
            this.lblReorderLevel.AutoSize = true;
            this.lblReorderLevel.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblReorderLevel.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblReorderLevel.Location = new System.Drawing.Point(560, 85);
            this.lblReorderLevel.Name = "lblReorderLevel";
            this.lblReorderLevel.Text = "Reorder Level";
            //
            // txtReorder
            //
            this.txtReorder.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtReorder.Location = new System.Drawing.Point(560, 110);
            this.txtReorder.Size = new System.Drawing.Size(160, 29);
            this.txtReorder.Name = "txtReorder";
            //
            // btnAdd
            //
            this.btnAdd.BackColor = System.Drawing.Color.FromArgb(46, 160, 90);
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.btnAdd.ForeColor = System.Drawing.Color.White;
            this.btnAdd.Location = new System.Drawing.Point(790, 20);
            this.btnAdd.Size = new System.Drawing.Size(230, 42);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Text = "Add Product";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            //
            // btnUpdate
            //
            this.btnUpdate.BackColor = System.Drawing.Color.FromArgb(30, 120, 220);
            this.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdate.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.btnUpdate.ForeColor = System.Drawing.Color.White;
            this.btnUpdate.Location = new System.Drawing.Point(790, 72);
            this.btnUpdate.Size = new System.Drawing.Size(230, 42);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            //
            // btnDelete
            //
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(220, 60, 60);
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.btnDelete.ForeColor = System.Drawing.Color.White;
            this.btnDelete.Location = new System.Drawing.Point(790, 124);
            this.btnDelete.Size = new System.Drawing.Size(230, 42);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            //
            // btnClear
            //
            this.btnClear.BackColor = System.Drawing.Color.FromArgb(225, 235, 240);
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClear.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.btnClear.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnClear.Location = new System.Drawing.Point(790, 176);
            this.btnClear.Size = new System.Drawing.Size(230, 42);
            this.btnClear.Name = "btnClear";
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            //
            // lblList
            //
            this.lblList.AutoSize = true;
            this.lblList.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            this.lblList.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblList.Location = new System.Drawing.Point(25, 438);
            this.lblList.Name = "lblList";
            this.lblList.Text = "Product List";
            //
            // btnRefresh
            //
            this.btnRefresh.BackColor = System.Drawing.Color.White;
            this.btnRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRefresh.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnRefresh.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnRefresh.Location = new System.Drawing.Point(170, 437);
            this.btnRefresh.Size = new System.Drawing.Size(90, 30);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = false;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            //
            // lblSearch
            //
            this.lblSearch.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
            this.lblSearch.AutoSize = true;
            this.lblSearch.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblSearch.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblSearch.Location = new System.Drawing.Point(790, 442);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Text = "Search";
            //
            // txtSearch
            //
            this.txtSearch.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
            this.txtSearch.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtSearch.Location = new System.Drawing.Point(860, 438);
            this.txtSearch.Size = new System.Drawing.Size(220, 29);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            //
            // grid
            //
            this.grid.AllowUserToAddRows = false;
            this.grid.AllowUserToDeleteRows = false;
            this.grid.AllowUserToResizeRows = false;
            this.grid.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
            this.grid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.grid.BackgroundColor = System.Drawing.Color.White;
            this.grid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.grid.ColumnHeadersHeight = 32;
            this.grid.EnableHeadersVisualStyles = false;
            this.grid.Location = new System.Drawing.Point(25, 475);
            this.grid.Size = new System.Drawing.Size(1055, 225);
            this.grid.MultiSelect = false;
            this.grid.Name = "grid";
            this.grid.ReadOnly = true;
            this.grid.RowHeadersVisible = false;
            this.grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grid.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.grid.SelectionChanged += new System.EventHandler(this.grid_SelectionChanged);
            this.grid.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.grid_DataBindingComplete);
            this.pnlHeader.Controls.Add(this.lblWelcome);
            this.pnlHeader.Controls.Add(this.lblRole);
            this.pnlHeader.Controls.Add(this.btnLogout);
            this.pnlTotal.Controls.Add(this.stripTotal);
            this.pnlTotal.Controls.Add(this.lblTitleTotal);
            this.pnlTotal.Controls.Add(this.lblCountTotal);
            this.pnlInStock.Controls.Add(this.stripInStock);
            this.pnlInStock.Controls.Add(this.lblTitleInStock);
            this.pnlInStock.Controls.Add(this.lblCountInStock);
            this.pnlLow.Controls.Add(this.stripLow);
            this.pnlLow.Controls.Add(this.lblTitleLow);
            this.pnlLow.Controls.Add(this.lblCountLow);
            this.pnlOut.Controls.Add(this.stripOut);
            this.pnlOut.Controls.Add(this.lblTitleOut);
            this.pnlOut.Controls.Add(this.lblCountOut);
            this.pnlForm.Controls.Add(this.lblProductName);
            this.pnlForm.Controls.Add(this.txtName);
            this.pnlForm.Controls.Add(this.lblCategory);
            this.pnlForm.Controls.Add(this.cmbCategory);
            this.pnlForm.Controls.Add(this.lblUnitPrice);
            this.pnlForm.Controls.Add(this.txtPrice);
            this.pnlForm.Controls.Add(this.lblDescription);
            this.pnlForm.Controls.Add(this.txtDescription);
            this.pnlForm.Controls.Add(this.lblQuantity);
            this.pnlForm.Controls.Add(this.txtQuantity);
            this.pnlForm.Controls.Add(this.lblReorderLevel);
            this.pnlForm.Controls.Add(this.txtReorder);
            this.pnlForm.Controls.Add(this.btnAdd);
            this.pnlForm.Controls.Add(this.btnUpdate);
            this.pnlForm.Controls.Add(this.btnDelete);
            this.pnlForm.Controls.Add(this.btnClear);
            //
            // DashboardForm
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(215, 250, 255);
            this.ClientSize = new System.Drawing.Size(1100, 720);
            this.MinimumSize = new System.Drawing.Size(1116, 759);
            this.Controls.Add(this.grid);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.lblSearch);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.lblList);
            this.Controls.Add(this.pnlForm);
            this.Controls.Add(this.pnlOut);
            this.Controls.Add(this.pnlLow);
            this.Controls.Add(this.pnlInStock);
            this.Controls.Add(this.pnlTotal);
            this.Controls.Add(this.pnlHeader);
            this.Name = "DashboardForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "INVENTORY MANAGEMENT SYSTEM - Dashboard";
            ((System.ComponentModel.ISupportInitialize)(this.grid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Label lblRole;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Panel pnlTotal;
        private System.Windows.Forms.Panel stripTotal;
        private System.Windows.Forms.Label lblTitleTotal;
        private System.Windows.Forms.Label lblCountTotal;
        private System.Windows.Forms.Panel pnlInStock;
        private System.Windows.Forms.Panel stripInStock;
        private System.Windows.Forms.Label lblTitleInStock;
        private System.Windows.Forms.Label lblCountInStock;
        private System.Windows.Forms.Panel pnlLow;
        private System.Windows.Forms.Panel stripLow;
        private System.Windows.Forms.Label lblTitleLow;
        private System.Windows.Forms.Label lblCountLow;
        private System.Windows.Forms.Panel pnlOut;
        private System.Windows.Forms.Panel stripOut;
        private System.Windows.Forms.Label lblTitleOut;
        private System.Windows.Forms.Label lblCountOut;
        private System.Windows.Forms.Panel pnlForm;
        private System.Windows.Forms.Label lblProductName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.ComboBox cmbCategory;
        private System.Windows.Forms.Label lblUnitPrice;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.Label lblQuantity;
        private System.Windows.Forms.TextBox txtQuantity;
        private System.Windows.Forms.Label lblReorderLevel;
        private System.Windows.Forms.TextBox txtReorder;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label lblList;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.DataGridView grid;
    }
}

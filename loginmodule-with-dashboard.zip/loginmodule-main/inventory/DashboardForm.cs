using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace inventory
{
    public partial class DashboardForm : Form
    {
        DataTable table;
        int selectedId = 0;
        bool filling = false;

        public DashboardForm(AppUser user)
        {
            InitializeComponent();
            lblWelcome.Text = "Welcome, " + user.FullName + "!";
            lblRole.Text = "Signed in as " + user.Username + " (" + user.UserRole + ")";

            cmbCategory.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbCategory.Items.AddRange(ProductService.Categories);
            cmbCategory.SelectedIndex = 0;
            txtDescription.Multiline = true;
            txtDescription.ScrollBars = ScrollBars.Vertical;

            // Grid look (matches the sign-in colours)
            grid.ColumnHeadersDefaultCellStyle.BackColor = Color.MidnightBlue;
            grid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            grid.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            grid.ColumnHeadersDefaultCellStyle.SelectionBackColor = Color.MidnightBlue;
            grid.DefaultCellStyle.SelectionBackColor = Color.FromArgb(30, 120, 220);
            grid.DefaultCellStyle.SelectionForeColor = Color.White;
            grid.GridColor = Color.FromArgb(225, 235, 240);

            Load += (s, e) => LoadProducts();
        }

        // ---------- data ----------
        void LoadProducts()
        {
            try
            {
                table = ProductService.GetAll();
                table.Columns.Add("Status", typeof(string));
                foreach (DataRow r in table.Rows)
                    r["Status"] = StatusOf(ToInt(r["Quantity"]), ToInt(r["ReorderLevel"]));

                grid.DataSource = table.DefaultView;
                ApplySearch();
                UpdateStats();
                ClearForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Could not load products:\n" + ex.Message, "Dashboard",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        static int ToInt(object o) { return o == null || o == DBNull.Value ? 0 : Convert.ToInt32(o); }

        static string StatusOf(int qty, int reorder)
        {
            if (qty <= 0) return "Out of Stock";
            if (qty <= reorder) return "Low Stock";
            return "In Stock";
        }

        void UpdateStats()
        {
            int total = 0, inStock = 0, low = 0, out_ = 0;
            foreach (DataRow r in table.Rows)
            {
                total++;
                switch ((string)r["Status"])
                {
                    case "In Stock": inStock++; break;
                    case "Low Stock": low++; break;
                    default: out_++; break;
                }
            }
            lblCountTotal.Text = total.ToString();
            lblCountInStock.Text = inStock.ToString();
            lblCountLow.Text = low.ToString();
            lblCountOut.Text = out_.ToString();
        }

        void ApplySearch()
        {
            if (table == null) return;
            string t = txtSearch.Text.Trim().Replace("'", "''")
                .Replace("[", "[[]").Replace("*", "[*]").Replace("%", "[%]");
            table.DefaultView.RowFilter = t == "" ? "" :
                "ProductName LIKE '%" + t + "%' OR Category LIKE '%" + t + "%' OR Description LIKE '%" + t + "%'";
        }

        // ---------- grid ----------
        private void grid_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            if (grid.Columns.Count == 0) return;
            grid.Columns["ProductID"].HeaderText = "ID";
            grid.Columns["ProductID"].FillWeight = 30;
            grid.Columns["ProductName"].HeaderText = "Product Name";
            grid.Columns["Description"].FillWeight = 120;
            grid.Columns["UnitPrice"].HeaderText = "Unit Price";
            grid.Columns["UnitPrice"].DefaultCellStyle.Format = "N2";
            grid.Columns["UnitPrice"].FillWeight = 60;
            grid.Columns["Quantity"].FillWeight = 55;
            grid.Columns["ReorderLevel"].HeaderText = "Reorder Level";
            grid.Columns["ReorderLevel"].FillWeight = 65;
            grid.Columns["CreatedAt"].HeaderText = "Created";
            grid.Columns["CreatedAt"].DefaultCellStyle.Format = "g";

            foreach (DataGridViewRow row in grid.Rows)
            {
                string s = Convert.ToString(row.Cells["Status"].Value);
                row.Cells["Status"].Style.ForeColor =
                    s == "In Stock" ? Color.FromArgb(30, 130, 70) :
                    s == "Low Stock" ? Color.FromArgb(200, 110, 0) : Color.FromArgb(200, 40, 40);
                row.Cells["Status"].Style.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            }
        }

        private void grid_SelectionChanged(object sender, EventArgs e)
        {
            if (filling || grid.CurrentRow == null || grid.SelectedRows.Count == 0) return;
            var r = grid.CurrentRow;
            filling = true;
            selectedId = ToInt(r.Cells["ProductID"].Value);
            txtName.Text = Convert.ToString(r.Cells["ProductName"].Value);
            string cat = Convert.ToString(r.Cells["Category"].Value);
            if (cat != "" && cmbCategory.FindStringExact(cat) < 0) cmbCategory.Items.Add(cat);
            cmbCategory.SelectedIndex = cat == "" ? 0 : cmbCategory.FindStringExact(cat);
            txtDescription.Text = Convert.ToString(r.Cells["Description"].Value);
            txtPrice.Text = Convert.ToDecimal(r.Cells["UnitPrice"].Value == DBNull.Value ? 0m : r.Cells["UnitPrice"].Value).ToString("0.00");
            txtQuantity.Text = ToInt(r.Cells["Quantity"].Value).ToString();
            txtReorder.Text = ToInt(r.Cells["ReorderLevel"].Value).ToString();
            filling = false;
        }

        // ---------- form ----------
        void ClearForm()
        {
            filling = true;
            selectedId = 0;
            txtName.Clear();
            cmbCategory.SelectedIndex = 0;
            txtDescription.Clear();
            txtPrice.Clear();
            txtQuantity.Clear();
            txtReorder.Clear();
            grid.ClearSelection();
            filling = false;
            txtName.Focus();
        }

        bool ReadForm(out Product p)
        {
            p = null;
            string name = txtName.Text.Trim();
            decimal price; int qty, reorder;

            if (name == "") return Warn("Please enter a product name.", txtName);
            if (!decimal.TryParse(txtPrice.Text.Trim(), out price) || price < 0)
                return Warn("Unit price must be a number (0 or more).", txtPrice);
            if (!int.TryParse(txtQuantity.Text.Trim(), out qty) || qty < 0)
                return Warn("Quantity must be a whole number (0 or more).", txtQuantity);
            if (!int.TryParse(txtReorder.Text.Trim(), out reorder) || reorder < 0)
                return Warn("Reorder level must be a whole number (0 or more).", txtReorder);

            p = new Product
            {
                ProductID = selectedId,
                ProductName = name,
                Category = cmbCategory.Text,
                Description = txtDescription.Text.Trim(),
                UnitPrice = price,
                Quantity = qty,
                ReorderLevel = reorder
            };
            return true;
        }

        bool Warn(string msg, Control focus)
        {
            MessageBox.Show(msg, "Product", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            focus.Focus();
            return false;
        }

        void Run(Action action)
        {
            try { action(); LoadProducts(); }
            catch (Exception ex)
            {
                MessageBox.Show("Database error:\n" + ex.Message, "Product",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Product p;
            if (!ReadForm(out p)) return;
            Run(() => ProductService.Add(p));
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (selectedId == 0)
            {
                MessageBox.Show("Select a product from the list first.", "Product",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            Product p;
            if (!ReadForm(out p)) return;
            Run(() => ProductService.Update(p));
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (selectedId == 0)
            {
                MessageBox.Show("Select a product from the list first.", "Product",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (MessageBox.Show("Delete \"" + txtName.Text + "\"? This cannot be undone.", "Delete Product",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            int id = selectedId;
            Run(() => ProductService.Delete(id));
        }

        private void btnClear_Click(object sender, EventArgs e) { ClearForm(); }
        private void btnRefresh_Click(object sender, EventArgs e) { txtSearch.Clear(); LoadProducts(); }
        private void txtSearch_TextChanged(object sender, EventArgs e) { ApplySearch(); }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            Close(); // SignInForm re-appears via FormClosed
        }
    }
}
